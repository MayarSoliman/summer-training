var input= prompt("please enter a word!")
for(let i=input.length ; i>=0;i--){
    var letter = input.charAt(i);
    document.write(letter)

}