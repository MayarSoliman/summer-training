var input1 = prompt("please enter a number")


if (isNaN(input1))
{
    console.log("invalid input")
}
else{
    if(input1==0 ){
        console.log("multiple of 8 and 5")
    }

    else if(input1%8==0 ){
        console.log("multiple of 8")

    }
    else if(input1%5==0 ){
        console.log("multiple of 5")

    }
    
    else{
        console.log("not a multiple of 5 nor 8")
    }

}