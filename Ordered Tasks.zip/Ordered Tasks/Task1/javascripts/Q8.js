var input1 = prompt("please enter the first number")
var input2 = prompt("please enter the second number")
var input3 = prompt("please enter the third number")

if(isNaN(input1)|| isNaN(input1)||isNaN(input1) ){

    console.log("invalid input")
}
else{

    if( input1 != input2 && input1!=input3 && input2!=input3){
        if(input1 > input2 && input1 > input3){
            console.log("the largest number" + input1)
        }
        else if(input2 > input1 && input2 > input3){
            console.log("the largest number"+ input2)
        }
        else if(input3 > input1 && input3 > input2){
            console.log("invalid input" + input3)
       }
    } 
    else
    {
        console.log("there are similar inputs so, there is no largest number" )


    }

}