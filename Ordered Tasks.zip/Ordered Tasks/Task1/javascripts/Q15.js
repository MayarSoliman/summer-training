var input1=Number(prompt("please enter the first number"))
var input2=Number(prompt("please enter the second number"))
var op=prompt("please enter the operation")
if(op=='+'){
    document.write(`the result is  ${input1 + input2}`)
}
else if(op=='-'){
    document.write(`the result is  ${input1 - input2}`)
}
else if(op=='/'){
    document.write(`the result is ${input1 / input2}`)
}
else if(op=='*'){
    document.write(`the result is ${input1 + input2}`)
}
else{
    document.write("invalid operation")
}