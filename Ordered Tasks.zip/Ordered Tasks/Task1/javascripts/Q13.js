var x=2
var y=3
console.log(`sum ="+ ${x+y}`)