var num=prompt("please enter a number")

if(isNaN (num))
{
    console.log("invalid datatype")
     
}
else{

   

    if(num%2===0){

        console.log("Even")
    }
    else if(num%2!==0){
    
        console.log("odd")
    }
}