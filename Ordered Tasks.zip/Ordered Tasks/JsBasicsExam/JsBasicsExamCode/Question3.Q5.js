var input = Number(prompt("enter a number"))
var result=1;
if(input==0){

}
else{
    for (let i=1;i<=input;i++){
        result*=i

    }
}
document.write("the result is =" +result)