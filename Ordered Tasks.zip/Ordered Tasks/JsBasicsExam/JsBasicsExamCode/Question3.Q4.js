var ar=[1,2,3,4,5];

function min(arr){
   var length=arr.length;
   var minimun= arr[0];
   for( let i=1; i<length ;i++){
        if(arr[i]<minimun){
            minimun=arr[i];
        }
    }
return minimun;
}

var result =min(ar)
console.log(result)


