function append(element,arr){
    arr.push(element);
   

}
function preappend(element,arr){
    arr.unshift(element);
   

}
let arrTest=['first','second'];
let elementTest='third';

append(elementTest,arrTest)

preappend(elementTest,arrTest)


