var a = 1,
    b = 2;

[a, b] = [b, a];

console.log('a:', a, 'b:', b);