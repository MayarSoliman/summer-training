var input= prompt("please enter a word!")
for(let i=0 ; i<=input.length;i++){
    var letter = input.charAt(i);
    document.write(letter)

}