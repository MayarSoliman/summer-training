var Array=[1,2,3,4,5]

function max(arr){
   var length=arr.length
   var max= arr[0]
   for( let i=1; i<length ;i++){
        if(arr[i]>max){
            max=arr[i]
        }
    }
return max
}

function max(Array)
