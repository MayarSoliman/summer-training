let ob ={
    a:1,
    b:2

}
var bigArr= Object.entries(ob);
var firstElemnt =bigArr[0]
var secondElemnt =bigArr[1]
var FinalArr=[]
FinalArr.push(secondElemnt)
FinalArr.push(firstElemnt)



