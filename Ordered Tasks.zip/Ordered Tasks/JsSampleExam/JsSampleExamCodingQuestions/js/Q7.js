function reverse (arr){
    
    arr.reverse();
    return arr
}

function reverse2 (arr){
    var arr1=[]
    for(let i=0 ; i<arr.length ;i++){
        var variable =arr[i];
        arr1.unshift(variable);
    }
    return arr1
}
var arr=[1,2,3,4]
var newarr=reverse2(arr)

for(let i=0 ; i<arr.length ;i++){
    console.log(newarr[i]);


}
