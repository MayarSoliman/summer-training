var arr=['ahmed', 'John']
var flag = false
for(let i=0 ; i<arr.length ;i++){
    if("John"==arr[i]){
        flag=true
    }

}
document.write("is it found ?"+flag)