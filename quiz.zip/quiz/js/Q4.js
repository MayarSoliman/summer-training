var dateinput1=prompt("enter the first date in mm/dd/yyyy form")
var dateinput2=prompt("enter the second date in mm/dd/yyyy form")

var date1 = new Date(dateinput1);
var date2 = new Date(dateinput2);

var diffOfDays = parseInt((date2 - date1) / (1000 * 60 * 60 * 24), 10); 
if(diffOfDays<0){
    diffOfDays*-1
}
console.log(diffOfDays+"days" )