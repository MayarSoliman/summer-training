alert("please enter the clock first then enter (am/pm)")
var clock=prompt("please enter the clock")
var A=prompt("please enter am/pm")
if(A=="am"){
    alert("the time is"+clock)
}else
{
    if(clock==12){
    alert("the time is 0")}
    else{
        let sum=Number(clock)+12
        alert("the time is "+sum)
    }

    }
    

