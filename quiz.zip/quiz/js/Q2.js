function thirdfun(){
    console.log("third")
}

function secondfun(){
    console.log("second")
    thirdfun()
}

function firstfun(){
    console.log("first")
    secondfun()
}
firstfun()