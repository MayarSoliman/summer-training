function add(x,y){
    return x+y
}
var a=add(2)(3);
document.write(a);
