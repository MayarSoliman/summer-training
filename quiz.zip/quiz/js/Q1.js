function sumObjectValues(object){

    var sum=0;
    var objectValuesarr=Object.values(object);
    var numOfValues=objectValuesarr.length;
    
    for(let i=0; i<numOfValues;i++){
        if(!isNaN(objectValuesarr[i])){
        
            sum+=objectValuesarr[i];
        }


    }
    return sum;

}
let car ={
    name :"Mycar",
    price:1000,
    price2:1000
}
var result=  sumObjectValues(car)
console.log(result)