var ar=[1,2,3,4,5];

function max(arr){
   var length=arr.length;
   var maximum= arr[0];
   for( let i=1; i<length ;i++){
        if(arr[i]>maximum){
            maximum=arr[i];
        }
    }
return maximum;
}

var result =max(ar)
console.log(result)


