function helloname(name){
    
    return ["hello", name]
}
function helloname2(name){
    
    return ("hello"+ name)
}
var name1= "Mayar";
var greeting =helloname(name1);
console.log(greeting[0]+greeting[1])