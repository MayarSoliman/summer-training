var answer = prompt("please enter your turn number")

if(isNaN(answer)){
    console.log("invalid input must be number")
}
else{

    //checks if it's divisable by 5
    if(answer%5 == 0){
        console.log("Fizz!")
    }
   
    //checks if it's divisable by 7
    if(answer%7 == 0){
        console.log("Buzz!")
    }
    for(let i=0; i<answer.length ; i++){

    //checks if it contains 
        let has = answer.charAt(i)
        
        if(has == "5"){
        console.log("Fizz!")
    }
    //checks if it contains 
        else if(has == "7"){
        console.log("Buzz!")
    }

}



}