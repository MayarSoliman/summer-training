var input1 = prompt("please enter the first number")
var input2 = prompt("please enter the second number")

if (isNaN(input1)|| isNaN(input2))
{
    console.log("invalid input")
}
else{
    if ( input1>0 && input2>0 ){
    console.log("both numbers are positive")
}
    else if ( input1<0 && input2<0 ){
    console.log("both numbers are negative")
}
    else if ( input1>0 && input2<0){
    console.log("the first number is  a positive number and the second number is a negative number")
     }else{
    console.log("the second number is  a positive number and the first number is a negative number")

}
}