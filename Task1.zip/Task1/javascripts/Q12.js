var n = input.length;
var input=prompt("please enter the intput")
var elements = new Array()
for(i=0;i<10;i++) {
    if(n>=0){
        elements[i]=input.charAt(n)

    document.write(" element "+i+":"+input.charAt(i)+"<br>")}
    else{
    document.write(" element "+ i + ":" + " - " + "<br>")}
}