var input=prompt("enter the number")
if(isNaN(input)){
    document.write("invalid input")
}
else{
    if(input>0){
        console.log("positive")
    }
    else{
        console.log("negative")

    }
}