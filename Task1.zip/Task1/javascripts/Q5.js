var input1 = prompt("please enter the first number")
var input2 = prompt("please enter the second number")
var sum = Number(input1) + Number(input2)
if ( sum==50 || input1==50 || input2==50){
    console.log("true")
}
