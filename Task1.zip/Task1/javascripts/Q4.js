var r=prompt("please enter the radius of the circle")
if(isNaN(r)){
    console.log("invalid datatype!")

}
else{
    Circumference= 2*r*3.14
    console.log("the Circumference is"+ Circumference)

    Area =3.14*r^2
    console.log("the Area is"+ Area)


}